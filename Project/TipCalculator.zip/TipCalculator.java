package application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
public class TipCalculator {
	
	@FXML
	private Label myLabel;
	@FXML
	private TextField textField;
	@FXML
	private Button myButton;
	
	int charge;
	
	public void calculate(ActionEvent event) {
		charge = Integer.parseInt(textField.getText());
		int result = (int)(charge*(20/100.0f));
		myLabel.setText(result + ".00$");
	}

}
